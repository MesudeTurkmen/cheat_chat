# Cheat Chat
A Python-based chat application using Redis and MySQL.

## Installation
working on that

## Authors
Abdullah Zeynel & Zeren Kavaz & Kerem Durgut & Mesude Türkmen
